<?php
$_SESSION['fr_entityName'] = "hello";
    ?>
